
package Modulos;

import Estructuras.Token;
import Excepciones.*;
import TablaDeSimbolos.*;
import AST.*;
import java.util.ArrayList;



  public class AnalizadorSintactico {
    private static Token tokenActual;
    private static AnalizadorLexico lexico;
    public static TS tablaSimbolos;


  

  public AnalizadorSintactico(AnalizadorLexico alex) {
	lexico = alex;
	
		try {
			tokenActual = lexico.getToken();
		} catch (ExcepcionLexica e1) {
			e1.getMessage();
		
		}
	

		try {
			
		tablaSimbolos= new TS();
		Inicial();
		tablaSimbolos.consolidar();
		System.out.println("Compilacion Exitosa");  
		System.out.println("[SinErrores]");
		
		} catch (Excepcion ex) {
			System.out.println(ex.getError());
		}

}

    //Comienzo a implementar los m�todos del analizador sint�ctico
    
    private static Token match(String aComparar, String error) throws Excepcion{
        //System.out.println("aComparar es:"+ aComparar);
        //System.out.println("TokenActual es:"+ tokenActual.getNombre());
    	Token toRet=null;
    	if(aComparar.equals(tokenActual.getNombre())){
            toRet= new Token(tokenActual.getNombre(), tokenActual.getLexema(), tokenActual.getLinea(), tokenActual.getColumna());

            try {
				tokenActual = lexico.getToken();
			} catch (ExcepcionLexica e) {
					e.getMessage();
			}
        }
        else
            throw new ExcepcionSintactica(tokenActual,error);
    	
    	return toRet;
    }
    
    
    private static boolean contenido(String[] aComparar){
        boolean toRet=false;
        for (int i=0; i<aComparar.length && !toRet; i++){
            if(aComparar[i].equals(tokenActual.getNombre()))
                toRet=true;
        }
        return toRet;
    }
    
    public static void Inicial() throws Excepcion{
    	     ListaClases();
        
    }
    
    private static void ListaClases() throws Excepcion{
    	Clase();
    	ListaClasesF();
    }
    
    private static void ListaClasesF() throws Excepcion {
            if(tokenActual.getNombre().equals("PR_Class"))
                Inicial();
            else if(tokenActual.getNombre().equals("EOF")){
                //Esto es as� porque los siguientes de InicialFact es vac�o
            }else 
                throw new ExcepcionSintactica(tokenActual, "class");
    }
    
    
    private static void Clase() throws Excepcion{
        match("PR_Class","class");
        Token idClase=match("PR_idClase","una clase");
        Clase nueva = new Clase(idClase);
        tablaSimbolos.setClaseActual(nueva);
        tablaSimbolos.insertarClase(nueva);
        ClaseF();
        tablaSimbolos.setClaseActual(null);

    }
    
   
    
    private static void ClaseF() throws Excepcion{
        if(tokenActual.getNombre().equals("P_Llave_Abre")){
            tablaSimbolos.getClaseActual().setHerencia("Object");
            match("P_Llave_Abre","{");
            ListaMiembros();
            match("P_Llave_Cierra","}");
        }else if (tokenActual.getNombre().equals("PR_Extends")){
            String hereda=Herencia();
            tablaSimbolos.getClaseActual().setHerencia(hereda);
            //Herencia();
            match("P_Llave_Abre","{");
            ListaMiembros();
            match("P_Llave_Cierra","}");
        }else 
            throw new ExcepcionSintactica(tokenActual, "{ o extends");
    }
    
    
    private static String Herencia() throws Excepcion {
        match("PR_Extends","extends");
        Token id=match("PR_idClase","una clase");
        return id.getLexema();

    }
    
   
    
    private static void ListaMiembros() throws Excepcion{
        String[] primerosMiembro = {"PR_Public", "PR_Private","PR_Static","PR_Dynamic","PR_Class"};
        if(tokenActual.getNombre().equals("P_Llave_Cierra")){
          
        }else if(contenido(primerosMiembro)){
        	//atributo 
            Miembro();			
            ListaMiembros();
        }
        else if(tokenActual.getNombre().equals("PR_idClase")){
        	//Es un constructor
        	Constructor();
        	ListaMiembros();                
        }else
          throw new ExcepcionSintactica(tokenActual, "un modificador de acceso (para un atributo), una clase (para un constructor), un tipo estatico o dinamico (para un metodo) o una llave que cierra");
    }
    
    private static void Miembro() throws Excepcion{
        String[] primerosAtributo ={"PR_Public","PR_Private"};
        String[] primerosMetodo={"PR_Static","PR_Dynamic"};
        if(contenido(primerosAtributo)){
            Atributo();            
        }else if(tokenActual.getNombre().equals("PR_idClase")){
            Constructor();            
        }else if(contenido(primerosMetodo)){
            Metodo();
        }else{
          throw new ExcepcionSintactica(tokenActual, "un modificador de acceso (para un atributo), una clase (para un constructor), un tipo estatico o dinamico (para un metodo) o una llave que cierra");
        }
    }
    
    
    private static void Atributo() throws Excepcion{
        String visibilidad=Visibilidad();
        Tipo tipo=Tipo(); 
        ListaDecAtrs(tipo, visibilidad,null);
        match("P_Puntoycoma","un punto y coma");

        
    }	
    
    
    private static String Visibilidad() throws Excepcion{    
        String toRet="";
        switch (tokenActual.getNombre()) {
            case "PR_Public":
                toRet="public";
                match("PR_Public","public");
                break;
            case "PR_Private":
                toRet="private";
                match("PR_Private","private");
                break;
            default:
                throw new ExcepcionSintactica(tokenActual, "un modificador de acceso valido");
        }
        return toRet;
    }
    
    
    private static Tipo Tipo() throws Excepcion {
        String[] primerosTipoPrimitivo={"PR_Boolean","PR_Char","PR_Int","PR_String"};
        Tipo toRet=null;
        if(contenido(primerosTipoPrimitivo))
            toRet=TipoPrimitivo();
        else if(tokenActual.getNombre().equals("PR_idClase")) {
        	Token id= match("PR_idClase","una clase");
            toRet= new TipoClase(id.getLexema());
        }else
            throw new ExcepcionSintactica(tokenActual, "un tipo primitivo o una clase");
        return toRet;

    }
    
    private static TipoPrimitivo TipoPrimitivo() throws Excepcion{
        TipoPrimitivo tipo=null;
       switch(tokenActual.getNombre()){
           case "PR_Boolean": match("PR_Boolean","boolean");
           					tipo= new TipoBoolean();
                            break;
           case "PR_Char": match("PR_Char","char");
           					tipo= new TipoChar();
           					break;
           case "PR_Int": match("PR_Int","int");
           					tipo= new TipoInt();
           					break;
           case "PR_String": match("PR_String","String");
           					tipo= new TipoString();
           					break;
           default: throw new ExcepcionSintactica(tokenActual, "un tipo primitivo");
       } 
       return tipo;

    }
    
    
    
    private static void ListaDecAtrs(Tipo tipo,String visibilidad, Declaracion declaracion) throws Excepcion{
    	
    	Token id = match("PR_idMetVar","Identificador");
        if(tablaSimbolos.getUnidadActual()==null){
            Atributo nuevoAtributo= new Atributo(id, tipo, visibilidad, tablaSimbolos.getClaseActual());
            tablaSimbolos.getClaseActual().insertarAtributo(nuevoAtributo);  
        }
    	else{
    		Variable nueva= new Variable(id, tipo, tablaSimbolos.getClaseActual());
    		declaracion.insertarVariable(nueva);
    		tablaSimbolos.getBloqueActual().insertarVariable(nueva);
    	}
    
        ListaDecAtrsF(tipo,visibilidad,declaracion);


    }
    
    
    private static void ListaDecAtrsF(Tipo tipo,String visibilidad, Declaracion declaracion) throws Excepcion{
        if(tokenActual.getNombre().equals("P_Coma"))
        {
            match("P_Coma","una coma");
            ListaDecAtrs(tipo, visibilidad,declaracion);
        }else if(tokenActual.getNombre().equals("P_Puntoycoma")){
        
        }else if(tokenActual.getNombre().equals("O_Asignacion")){

            
        }else
            throw new ExcepcionSintactica(tokenActual, "una coma o un punto y coma o un igual");
        
    }
    
    
    private static void Constructor() throws Excepcion {
        Token id = match("PR_idClase","una clase");
        Constructor nuevoConst = new Constructor(id);
        tablaSimbolos.setUnidadActual(nuevoConst);
        tablaSimbolos.getClaseActual().insertarConstructor(nuevoConst);
        ArgsFormales();
        Bloque();
        tablaSimbolos.setUnidadActual(null);
    }
    
    
    private static void ArgsFormales() throws Excepcion {
        match("P_Parentesis_Abre","(");
        ListaArgsFormalesOVacio();
        match("P_Parentesis_Cierra",")");
    }
    
    
    private static void ListaArgsFormalesOVacio() throws Excepcion {
        String[] primerosListaArgsFormales = {"PR_Boolean","PR_Char","PR_Int","PR_String","PR_idClase"};
        
        if(contenido(primerosListaArgsFormales)){
            ListaArgsFormales();
            
        }else {
        	
        }

    }
    
    
    private static void ListaArgsFormales() throws Excepcion {
        ArgFormal();
        ListaArgsFormalesAux();
    }
    
    
    private static void ArgFormal() throws Excepcion {
        Tipo tipo= Tipo();
        Token id= match("PR_idMetVar","Identificador");
        Variable nueva= new Variable(id, tipo, tablaSimbolos.getClaseActual());
        tablaSimbolos.getUnidadActual().insertarArgumento(nueva);

    }
    
    
    private static void ListaArgsFormalesAux() throws Excepcion {
        if(tokenActual.getNombre().equals("P_Coma")){
            match("P_Coma","Coma");
            ListaArgsFormales();
        }else if( tokenActual.getNombre().equals("P_Parentesis_Cierra")){
            //epsilon
        }else
            throw new ExcepcionSintactica(tokenActual, "una coma o un parentesis que cierra");
    }
    
    
    
    private static Bloque Bloque() throws Excepcion {
        match("P_Llave_Abre","una llave que abre");
        Bloque nuevo= new Bloque(tablaSimbolos.getBloqueActual(), tablaSimbolos.getUnidadActual(), tablaSimbolos.getClaseActual());
        tablaSimbolos.setBloqueActual(nuevo);
        if(tablaSimbolos.getUnidadActual().getBloque()==null)
            tablaSimbolos.getUnidadActual().setBloque(nuevo);          
        ListaSentencias();
        match("P_Llave_Cierra","una llave que cierra o una sentencia bien formada");
        tablaSimbolos.setBloqueActual(nuevo.getBloqueSuperior());
        return nuevo;

    }
    
    
    
    
    private static void ListaSentencias() throws Excepcion {
        String[] primerosSentencia={"P_Puntoycoma","PR_idMetVar","P_Parentesis_Abre","PR_Boolean","PR_Char","PR_Int","PR_String","PR_If","PR_While","P_Llave_Abre","PR_Return","PR_idClase"};
        if(contenido(primerosSentencia)){
            Sentencia sentencia=Sentencia();
            tablaSimbolos.getBloqueActual().insertarSentencia(sentencia);
            ListaSentencias();
        }
        else {
        	//epsilon no hago nada
        }
    } 
    
    private static Sentencia Sentencia() throws Excepcion {
        String[] primerosTipo={"PR_Boolean","PR_Char","PR_Int","PR_String","PR_idClase"};
        Sentencia sent=null;
        Token id=null;
       
        if(tokenActual.getNombre().equals("P_Puntoycoma")){
            id=match("P_Puntoycoma","punto y coma");
            sent= new SentenciaVacia(id.getLinea(),id.getColumna());
        }
        else if(tokenActual.getNombre().equals("PR_idMetVar") || tokenActual.getNombre().equals("P_Parentesis_Abre") || tokenActual.getNombre().equals("PR_This") || tokenActual.getNombre().equals("PR_Static") || tokenActual.getNombre().equals("PR_New") ){
        	Primario p = Primario();		
        	Asignacion asig = Asignacion(p);
            id= match("P_Puntoycoma","punto y coma");
            if(asig == null)
            	sent= new Llamada(id.getLinea(),id.getColumna(),p);
            else
            	sent= asig;
        }
        else if( contenido(primerosTipo)){
            Tipo tipo=Tipo();
            Declaracion nueva= new Declaracion(-1, tablaSimbolos.getBloqueActual(), tablaSimbolos.getUnidadActual());
            ListaDecAtrs(tipo,null,nueva);
            id=match("P_Puntoycoma","punto y coma");
            nueva.setNroLinea(id.getLinea());//programacion defensiva
            sent=nueva;
        }else if (tokenActual.getNombre().equals("PR_If")){
            id=match("PR_If","if");
            match("P_Parentesis_Abre","(");
            Expresion exp=Expresion();
            match("P_Parentesis_Cierra",")");
            If nueva = new If(id.getLinea());
            nueva.setCondicion(exp);
            Sentencia sentAux=Sentencia();
            //Si es una declaraci�n entonces deber�amos sacarla del bloque de inmediato
            if(sentAux.esDeclaracion()){
                Declaracion aux= (Declaracion)sentAux;
                aux.eliminarVariables();
            }
            nueva.setSentencia(sentAux);
            Sentencia sentElse=SentenciaFIf();
            nueva.setSentenciaElse(sentElse);
            sent=nueva;

        }else if(tokenActual.getNombre().equals("PR_While")){
            id=match("PR_While","while");
            match("P_Parentesis_Abre","(");
            Expresion exp=Expresion();
            match("P_Parentesis_Cierra",")");
            While nueva = new While(id.getLinea());
            nueva.setCondicion(exp);
            Sentencia sentAux=Sentencia();
            if(sentAux.esDeclaracion()){
                Declaracion aux= (Declaracion)sentAux;
                aux.eliminarVariables();
            }
            nueva.setSentencia(sentAux);
            sent= nueva;
        }else if(tokenActual.getNombre().equals("P_Llave_Abre")){
        	sent=Bloque();    	
        }else if(tokenActual.getNombre().equals("PR_Return")){
            id=match("PR_Return","return");
            Retorno nueva = new Retorno(id.getLinea(), tablaSimbolos.getUnidadActual());
            SentenciaFRet(nueva);
            sent=nueva;

        }else
            throw new ExcepcionSintactica(tokenActual,"una sentencia bien formada");
        return sent;

    }
    
   
     private static Asignacion Asignacion(Primario p) throws Excepcion{
    	//System.out.println("entre a asignacion o llamada");
    	String[] primerosTipo={"O_Asignacion","O_SumaAsignacion","O_RestaAsignacion"};
    	Asignacion asig = null;
    	
    	if(contenido(primerosTipo)) {		
    		Token id = TipoDeAsignacion();
            Asignacion nueva = new Asignacion(id.getLinea(),id.getColumna(),id);
            nueva.setLadoIzquierdo(p);
            Expresion ladoDer=Expresion();
            nueva.setLadoDer(ladoDer);	
			asig= nueva;
    	}
    	return asig;
    }
     
     private static Token TipoDeAsignacion() throws Excepcion {
     	//System.out.println("entre a tipo asignacion");
     	Token t= null;
         if(tokenActual.getNombre().equals("O_Asignacion")){
             t = match("O_Asignacion","un operador asignacion");
         }else if(tokenActual.getNombre().equals("O_SumaAsignacion")){
             t = match("O_SumaAsignacion","un operador suma asignacion");
         }else if(tokenActual.getNombre().equals("O_RestaAsignacion")){
             t = match("O_RestaAsignacion","un operador resta asignacion");
         }else
             throw new ExcepcionSintactica(tokenActual, "un operador asignacion, suma asignacion o una resta asignacion");
         return t;
     }
    
    private static void SentenciaFRet(Retorno nueva) throws Excepcion {
        String[] primerosExpresion= {"O_Suma","O_Resta","O_Not","PR_This","PR_Null","PR_True","PR_False","Entero_Literal","Caracter_Literal","String_Literal","P_Parentesis_Abre","PR_idMetVar","PR_Class","PR_New"};
        if(contenido(primerosExpresion)){
            Expresion exp=ExpresionOVacio();
            nueva.setExpresion(exp);
            match("P_Puntoycoma","un punto y coma (;)");
        }else if(tokenActual.getNombre().equals("P_Puntoycoma")){
            match("P_Puntoycoma","un punto y coma (;)");
            
        }else
            throw new ExcepcionSintactica(tokenActual, "un punto y coma o una expresion v�lida");
    }
    
    
    private static Sentencia SentenciaFIf() throws Excepcion {
        Sentencia toRet=null;
        if(tokenActual.getNombre().equals("P_Llave_Cierra")){
            //epsilon
        }else if(tokenActual.getNombre().equals("PR_Else")){
            match("PR_Else","else");
            toRet=Sentencia();
            if(toRet.esDeclaracion()){
                Declaracion aux= (Declaracion)toRet;
                aux.eliminarVariables();
            }
        }
        return toRet;
    }
    
    private static Expresion ExpresionOVacio() throws Excepcion {
    	//System.out.println("entre a expresion o vacio");
    	
    	String[] primerosExpresion={"O_Suma","O_Resta","O_Not","PR_Null","PR_True","PR_False","Entero_Literal","Caracter_Literal","String_Literal","P_Parentesis_Abre","PR_idMetVar","PR_idClase","PR_New","PR_This"};    	
    	Expresion exp= null;
    	
    	if(contenido(primerosExpresion)){
            exp= Expresion();
        }
    	
    	if(tokenActual.getNombre().equals("P_Puntoycoma")) {
    		//epsilon no hago nada
    	}
    	else{
    		throw new ExcepcionSintactica(tokenActual, "una expresion");
        }
    	
    	return exp;
    }
    
    private static Expresion Expresion() throws Excepcion {
    	//System.out.println("entre a expresion");
    	
    	Expresion expUna= ExpresionUnaria();
    	ExpresionBinaria expBin= ExpresionAux(expUna);		
    	
    	return (expBin ==null)? expUna:expBin;  
    }
    
    private static ExpresionBinaria ExpresionAux(Expresion exp) throws Excepcion {
    	//System.out.println("entre a expresion aux");
    	
    	Token op= null;
    	
    	String[] primerosNada={"P_Puntoycoma","P_Coma","P_Llave_Cierra","P_Parentesis_Cierra"};
    	String[] primerosOperadoresBinarios={"O_Or","O_And","O_Comparacion","O_Distinto","O_Mayor","O_Menor","O_Mayorigual","O_Menorigual","O_Suma","O_Resta","O_Mult","O_Div","O_Mod"};
       
    	if(contenido(primerosOperadoresBinarios)){
            op = OperadorBinario();
            ExpresionBinaria expBi= new ExpresionBinaria(op.getLinea(),op.getColumna(),op.getNombre());
            expBi.setLadoIzquierdo(exp);
            expBi.setLadoDerecho(Expresion());
            return expBi;
        }else if(contenido(primerosNada)) {
			return null;
		}else{
			throw new ExcepcionSintactica(tokenActual, "un operador binario");
		}
    }
    
    private static Token OperadorBinario() throws Excepcion {
    	//System.out.println("entre a op binario");
    	
    	Token t= null;
    	
        switch(tokenActual.getNombre()){
            case "O_Or": t= match("O_Or","un operador or");break;
            case "O_And": t= match("O_And","un operador and");break;
            case "O_Comparacion": t= match("O_Comparacion","un operador comparacion");break;
            case "O_Distinto":t= match("O_Distinto","un operador distinto");break;
            case "O_Mayor": t= match("O_Mayor","un operador mayor");break;
            case "O_Menor": t= match("O_Menor","un operador menor");break;
            case "O_Mayorigual": t= match("O_Mayorigual","un operador >=");break;
            case "O_Menorigual": t= match("O_Menorigual","un operador <=");break;
            case "O_Suma": t= match("O_Suma","un operador mas");break;
            case "O_Resta": t= match("O_Resta","un operador menos");break;
            case "O_Mult": t= match("O_Mult","operador por");break;
            case "O_Div": t= match("O_Div","operador dividido");break;
            case "O_Mod": t= match("O_Mod","operador modulo");break;
            default: throw new ExcepcionSintactica(tokenActual, "un operador binario");
        }
        
        return t;
    } 
    
    private static Expresion ExpresionUnaria() throws Excepcion {
    	//System.out.println("entre a exp unaria");
    	
    	AST.Expresion expUna;
    	
    	
    	String[] primerosOperando={"PR_Null","PR_True","PR_False","Entero_Literal","Caracter_Literal","String_Literal","P_Parentesis_Abre","PR_idMetVar","PR_idClase","PR_New","PR_This","PR_Static"};
    	String[] primerosOperadorUnario={"O_Suma","O_Resta","O_Not"};
    	
   	 	if(contenido(primerosOperadorUnario)){
   	 		Token operadorUnario= OperadorUnario();
   	 		Expresion operando= Operando();
   	 		expUna= new ExpresionUnaria(operadorUnario.getNombre(),operadorUnario.getLinea(),operadorUnario.getColumna(),operando);
   	 	}
   	 	
   	 	if(contenido(primerosOperando)){
   	 		
  		  expUna= Operando();
  			    
   	 	}
   	 	else {
   	 		throw new ExcepcionSintactica(tokenActual, "un operando con un tipo de operador unario de ser necesario");
   	 	}
   	 	
   	 	return expUna;
    }
    
    private static Token OperadorUnario() throws Excepcion {
    	//System.out.println("entre a op unario");
    	
    	Token t= null;
    	
    	switch(tokenActual.getNombre()){
        case "O_Suma": t= match("O_Suma","un operador mas");break;
        case "O_Resta": t= match("O_Resta","un operador menos");break;
        case "O_Not": t= match("O_Not","un operador negacion");break;
        default: throw new ExcepcionSintactica(tokenActual, "un operador mas , menos o negacion");
    	}
    	
    	return t;
    }
    
   
    
    private static Expresion Operando() throws Excepcion {
        Expresion ret=null;
        String[] primerosLiteral={"PR_Null","PR_True","PR_False","Entero_Literal","Caracter_Literal","String_Literal"};
        String[] primerosPrimario={"P_Parentesis_Abre","PR_idMetVar","PR_idClase","PR_New"};
        
        if(contenido(primerosLiteral)){
            ret=Literal();
        }else if (contenido(primerosPrimario)){
            ret=Primario();
        }else
            throw new ExcepcionSintactica(tokenActual,"un operando");
        
        return ret;

    }
    
    private static Primario Primario() throws Excepcion {
        Primario toRet=null;
        Token id=null;
        Encadenado enc;
    	switch(tokenActual.getNombre()){
    		case "PR_This":								 	 				
    			id =match("PR_This","un this");
    			AccesoThis t= new AccesoThis(id.getLinea(), id.getColumna(),tablaSimbolos.getClaseActual(), tablaSimbolos.getUnidadActual(),id.getLexema());
    			enc= Encadenado();
    			t.setEncadenado(enc);
    			toRet= t;
    			break;
            case "P_Parentesis_Abre":
                id=match("P_Parentesis_Abre","(");
                Expresion exp=Expresion();
                match("P_Parentesis_Cierra",")");
                enc= Encadenado();
                toRet= new ExpresionParentizada(exp, id.getLinea(),id.getColumna(),id.getLexema());
                toRet.setEncadenado(enc);
                break;
            case "PR_idMetVar":
                id=match("PR_idMetVar","un identificador");
                toRet=AccesoMetOVar(id);
                break;
            case "PR_Static":
            	match("PR_Static","un static");
                Token idClase=match("PR_Class","una clase");
                match("P_Punto","un punto");
                AccesoEstatico llamada= AccesoEstatico(idClase);
                enc= Encadenado();
                llamada.setEncadenado(enc);
                toRet=llamada;
                break;
            case "PR_New":
                match("PR_New","new");
                id=match("PR_idClase","una clase");
                ArrayList<Expresion> argumentos=ArgsActuales();
                enc= Encadenado();
                AccesoConstructor nueva= new AccesoConstructor(id.getLexema(), argumentos, id.getLinea(),id.getColumna());
                nueva.setEncadenado(enc);
                toRet= nueva;
        }
    	
    	return toRet;
    }
    
    
    private static Primario AccesoMetOVar(Token id) throws Excepcion {
        Primario toRet=null;
        Encadenado enc=null;
        if(tokenActual.getNombre().equals("P_Parentesis_Abre")){
            ArrayList<Expresion> argumentos=ArgsActuales();
            enc= Encadenado();
            toRet= new AccesoMetodo(id.getLexema(), tablaSimbolos.getClaseActual(), argumentos, tablaSimbolos.getUnidadActual(), id.getLinea(),id.getColumna());
            toRet.setEncadenado(enc);
        }else{
            enc= Encadenado();
            toRet = new AccesoVar(id.getLexema(), tablaSimbolos.getBloqueActual(), tablaSimbolos.getUnidadActual(), tablaSimbolos.getClaseActual(), id.getLinea(),id.getColumna(),false);
            toRet.setEncadenado(enc);
        }
        return toRet;

    
    }
    
    
    private static AccesoEstatico AccesoEstatico(Token id) throws Excepcion{
        Token idMetodo=match("PR_idMetVar","un identificador");
        ArrayList<Expresion> argumentos=ArgsActuales();
        AccesoEstatico toRet= new AccesoEstatico(id.getLexema(), argumentos, idMetodo.getLexema(),  id.getLinea(),id.getColumna());
        return toRet;
    }
    
    
    private static ArrayList<Expresion> ArgsActuales() throws Excepcion {
        match("P_Parentesis_Abre","(");
        ArrayList<Expresion> listaExp = new ArrayList<Expresion>();
        ArgsActualesF(listaExp);
        return listaExp;

    }
    
    
    
    private static Encadenado Encadenado() throws Excepcion {
        Encadenado ret=null;
    	if(tokenActual.getNombre().equals("P_Punto")){
            ret= VarOMetodoEncadenado();
            Encadenado encAux= Encadenado();
            ret.setEncadenado(encAux);
        }
    	return ret;
    }
    
    
    
    private static Encadenado VarOMetodoEncadenado() throws Excepcion {
        match("P_Punto","un punto");
        Token id=match("PR_idMetVar","un identificador");
        return VarOMetodoEncadenadoF(id);
    }
    
    
    
    private static Encadenado VarOMetodoEncadenadoF(Token id) throws Excepcion {
        Encadenado toRet=null;
    	
        if(tokenActual.getNombre().equals("P_Parentesis_Abre")) {
            ArrayList<Expresion> listaExp=ArgsActuales();
            toRet= new MetodoEncadenado(id.getLexema(), listaExp);
        }else{
            toRet= new VarEncadenado(id.getLexema());
        }
        
        return toRet;
    }
    
    
    
    private static void ArgsActualesF(ArrayList<Expresion> expresiones) throws Excepcion{
    	String[] primerosListaExps = {"O_Suma","O_Resta","O_Not","PR_This","PR_Null","PR_True","PR_False","Entero_Literal","Caracter_Literal","String_Literal","P_Parentesis_Abre","PR_idMetVar","PR_idClase","PR_New"};
       
    	if(contenido(primerosListaExps)){
            ListaExpsOVacio(expresiones);
            match("P_Parentesis_Cierra",")");
        }else if(tokenActual.getNombre().equals("P_Parentesis_Cierra")){
            match("P_Parentesis_Cierra",")");
        }else
            throw new ExcepcionSintactica(tokenActual, "argumentos bien formados");
    }
    
    private static void ListaExpsOVacio(ArrayList<Expresion> expresiones) throws Excepcion {
    	//System.out.println("entre a lista exp o vacio");
       	String[] primerosExpresion={"O_Suma","O_Resta","O_Not","PR_Null","PR_True","PR_False","Entero_Literal","Caracter_Literal","String_Literal","P_Parentesis_Abre","PR_idMetVar","PR_idClase","PR_New","PR_This","PR_Static"};
    	    
    	if(contenido(primerosExpresion)){
        	ListaExps(expresiones);
    	}
    }
    
    private static void ListaExps(ArrayList<Expresion> expresiones) throws Excepcion{
        Expresion exp=Expresion();
        expresiones.add(exp);
        ListaExpsF(expresiones);
    }
    
    
    
    private static void ListaExpsF(ArrayList<Expresion> expresiones) throws Excepcion{
        if(tokenActual.getNombre().equals("P_Coma")){
            match("P_Coma","una coma");
            ListaExps(expresiones);
        }else if (tokenActual.getNombre().equals("P_Parentesis_Cierra")){
            //epsilon
        }else
            throw new ExcepcionSintactica(tokenActual, "una coma o un parentesis que cierra");
    }
    
    
    
    private static Expresion Literal() throws Excepcion {
        Expresion toRet=null;
        Token id;
    	switch(tokenActual.getNombre()){
            case "PR_Null": id=match("PR_Null","null"); toRet=new Null(id.getLinea(),id.getColumna());break;
            case "PR_True": id=match("PR_True","true");toRet=new BooleanLiteral(id.getLinea(),id.getColumna(),id.getLexema());break;
            case "PR_False": id=match("PR_False","false");toRet=new BooleanLiteral(id.getLinea(),id.getColumna(),id.getLexema());break;
            case "Entero_Literal": id=match("Entero_Literal","un entero");toRet=new EnteroLiteral(id.getLinea(),id.getColumna(),id.getLexema());break;
            case "Caracter_Literal": id=match("Caracter_Literal","un caracter");toRet=new CharLiteral(id.getLinea(),id.getColumna(),id.getLexema());break;
            case "String_Literal": id=match("String_Literal","un String literal");toRet=new StringLiteral(id.getLinea(),id.getColumna(),id.getLexema());break;
            default: throw new ExcepcionSintactica(tokenActual,"un literal");
        }
        return toRet;

    }
    
    private static void Metodo() throws Excepcion {
        String forma=FormaMetodo();  //devuelve static o dynamic
        MetodoF(forma);
        tablaSimbolos.setUnidadActual(null);

    }
    
    
    private static void MetodoF(String forma) throws Excepcion{
        TipoMetodo tipo=TipoMetodo();
        Token id=match("PR_idMetVar","un identificador");
        Metodo nuevoMetodo= new Metodo(id, forma, tipo, tablaSimbolos.getClaseActual());
        tablaSimbolos.setUnidadActual(nuevoMetodo);
        tablaSimbolos.getClaseActual().insertarMetodo(nuevoMetodo);
        ArgsFormales();
        Bloque();
    }

    
    private static TipoMetodo TipoMetodo() throws Excepcion {
        String[] primerosTipo={"PR_Boolean","PR_Char","PR_Int","PR_String","PR_idClase"};
        TipoMetodo tipo=null;
        if(contenido(primerosTipo)){
            tipo=Tipo();
        }else if(tokenActual.getNombre().equals("PR_Void")) {
            		match("PR_Void","void");
            		tipo=new TablaDeSimbolos.Void();
        }else
            throw new ExcepcionSintactica(tokenActual, "un tipo primitivo, una clase o void");
        return tipo;
    }
    
    
    
    
    private static String FormaMetodo() throws Excepcion {
        String toRet="";
    	switch(tokenActual.getNombre()){
            case "PR_Static": match("PR_Static","static"); toRet="static"; break;
            case "PR_Dynamic": match("PR_Dynamic","dynamic"); toRet="dynamic"; break;
            default: throw new ExcepcionSintactica(tokenActual,"static o dynamic");
        }
        return toRet;
    }
   
    
   
    
}


package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.TipoMetodo;


public class ExpresionParentizada extends Primario{
    private Expresion expresion;

    public ExpresionParentizada(Expresion expresion, int nroLinea, int nroColumna, String id) {
        super(nroLinea, nroColumna,id);
        this.expresion = expresion;
    }

    
    public TipoMetodo chequear() throws ExcepcionSemantico {
        TipoMetodo tipoExpresion= expresion.chequear();
        TipoMetodo toRet=null;
        if(encadenado!=null){
            if(tipoExpresion.esTipoVoid()){
                throw new ExcepcionSemantico("El tipo de la expresion parentizada no debe ser void", nroLinea, tipoExpresion.getNombreTipo());
            }
            toRet= encadenado.chequear(tipoExpresion,nroLinea, nroColumna);
        }else{
            toRet= tipoExpresion;
        }
        return toRet;
    }
    
}

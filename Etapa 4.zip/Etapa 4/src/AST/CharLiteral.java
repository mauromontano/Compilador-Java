package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.TipoChar;
import TablaDeSimbolos.TipoMetodo;


public class CharLiteral extends Literal{

    public CharLiteral(int nroLinea, int nroColumna, String id) {
        super(nroLinea, nroColumna, id);
    }

    
    public TipoMetodo chequear() throws ExcepcionSemantico {
        return new TipoChar();
    }
    
}

package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.TipoMetodo;


public class While extends Sentencia{
    private Expresion condicion;
    private Sentencia sentencia;
    public While(int nroLinea) {
        super();
        this.nroLinea=nroLinea;
    }

    public void setCondicion(Expresion condicion) {
        this.condicion = condicion;
    }

    public void setSentencia(Sentencia sentencia) {
        this.sentencia = sentencia;
    }
    
    
    public void chequear() throws ExcepcionSemantico {
        TipoMetodo t=condicion.chequear();
        if(!t.esTipoBoolean()){
            throw new ExcepcionSemantico("La condicion del while debe ser de tipo booleano", condicion.getNroLinea(), condicion.toString());
        }
        sentencia.chequear();
    }
    
}

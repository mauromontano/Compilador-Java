
package AST;
import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Tipo;
import TablaDeSimbolos.TipoMetodo;

import java.util.HashSet;
import java.util.Set;

import Estructuras.Token;

public class Asignacion extends Sentencia{
    private Primario ladoIzquierdo;
    private Expresion ladoDer;
	private Token tipoAsignacion;
    private Set<String> inicializadas;
    
    
    public Asignacion(int nroLinea , int nroColumna, Token tipoAsignacion) {
        this.nroLinea=nroLinea;
        this.nroColumna=nroColumna;
        this.tipoAsignacion= tipoAsignacion;
        inicializadas = new HashSet<String>();
    }

    public void setLadoIzquierdo(Primario ladoIzquierdo) {
        this.ladoIzquierdo = ladoIzquierdo;
    }

    public void setLadoDer(Expresion ladoDer) {
        this.ladoDer = ladoDer;
    }
    
    public Set<String> getInicializadas(){
        return inicializadas;
    }
    
    public void chequear() throws ExcepcionSemantico {
    	
    	if(!ladoIzquierdo.tieneEncadenado()){
			
			if(!(ladoIzquierdo instanceof AccesoVar))
				
				throw new ExcepcionSemantico(" El lado izquierdo de la asignacion "+ladoIzquierdo.getNombreVariable()+" debe ser una variable", ladoIzquierdo.nroLinea,ladoIzquierdo.getNombreVariable());
			else
				inicializadas.add(ladoIzquierdo.getNombreVariable());
		
		}else{
			
			if(!(getUltimoEncadenado(ladoIzquierdo.getEncadenado()) instanceof VarEncadenado))
				throw new ExcepcionSemantico("El ultimo elemento de la llamada encadenada del lado izquierdo de la asignacion "+ladoIzquierdo.getNombreVariable()+" debe ser una variable",ladoIzquierdo.getNroLinea(),ladoIzquierdo.getNombreVariable());
			
		}
    	
 
    	
        Tipo tipoIzquierdo=(Tipo)ladoIzquierdo.chequear();
        TipoMetodo tipoMetodoDerecho = ladoDer.chequear();
        
        if(tipoMetodoDerecho.esTipoVoid())
            throw new ExcepcionSemantico("No hay un tipo asignado a la evaluacion de la expresion ya que es void, se necesita el tipo "+tipoIzquierdo.getNombreTipo(),nroLinea,tipoIzquierdo.getNombreTipo());
        
        Tipo tipoDerecho= (Tipo)tipoMetodoDerecho; 
        
        switch (this.tipoAsignacion.getLexema()) {
		
        	case "+=":
        	case "-=":
					if( !(tipoIzquierdo.esTipoInt()) || !(tipoDerecho.esTipoInt()))
						throw new ExcepcionSemantico("El tipo de asinacion "+this.tipoAsignacion.getLexema()+" es incorrecto ya que el lado derecho o izquierdo no es de tipo entero",nroLinea,tipoIzquierdo.getNombreTipo());
								
		
			case "=":   // chequeo la conformidad
						if(!tipoDerecho.esCompatible(tipoIzquierdo))
				        	throw new ExcepcionSemantico("No es posible asignar el valor de la expresion que es de tipo "+tipoDerecho.getNombreTipo()+" a la variable "+ladoIzquierdo.getNombreVariable()+" que es del tipo "+tipoIzquierdo.getNombreTipo(), nroLinea,ladoIzquierdo.getNombreVariable());


		}
        
        /*
        if(!ladoIzquierdo.tieneEncadenado())
        	if(ladoIzquierdo instanceof AccesoVar) {
        		inicializadas.add(ladoIzquierdo.getNombreVariable());
        	}
        	else
        		throw new ExcepcionSemantico("El lado izquierdo de la asignacion "+ladoIzquierdo.getNombreVariable()+" debe ser una variable "+ladoIzquierdo.getNombreVariable(), nroLinea, ladoIzquierdo.getNombreVariable());
         */
   
    }
    
    private Encadenado getUltimoEncadenado(Encadenado encadenado){
		
		if(encadenado.getEncadenado() == null){
			return encadenado;
		}else{
			return getUltimoEncadenado(encadenado.getEncadenado());
		}
		
	}
    
}

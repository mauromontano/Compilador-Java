
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Atributo;
import TablaDeSimbolos.Clase;
import TablaDeSimbolos.Metodo;
import TablaDeSimbolos.TipoMetodo;
import TablaDeSimbolos.Unidad;


public class AccesoVar extends Primario{
    private String id;
    private Bloque bloqueActual;
    private Unidad unidadActual;
    private Clase claseActual;
    @SuppressWarnings("unused")
	private boolean esIzq;

    public AccesoVar(String id, Bloque bloqueActual, Unidad unidadActual, Clase claseActual, int nroLinea, int nroColumna,boolean esIzq) {
        super(nroLinea,nroColumna,id);
        this.id = id;
        this.bloqueActual = bloqueActual;
        this.unidadActual = unidadActual;
        this.claseActual = claseActual;
        this.esIzq=esIzq;
    }
    
    public String getNombreVariable(){
        return id;
    }
    
    public boolean tieneEncadenado(){
        return encadenado!=null;
    }
    
    
    public TipoMetodo chequear() throws ExcepcionSemantico {
        TipoMetodo toRet=null;
        Atributo atributo=null;
        @SuppressWarnings("unused")
		boolean estaEnBloque=false;
        //Primero chequeamos que el id se encuentre o bien en el bloque actual, en el parametro o en un atributo de la clase actual
        if(bloqueActual.chequearExistencia(id)==null){
            if(unidadActual.getParametro(id)==null){
                if(claseActual.getAtributo(id)==null){
                    throw new Excepciones.ExcepcionSemantico("El identificador "+id+" no ha sido definido",nroLinea, id);
                }else{
                    atributo= (Atributo)claseActual.getAtributo(id);
                    toRet= atributo.getTipo();
                }
            }else{
                toRet=unidadActual.getParametro(id).getTipo();
            }
        }else{
            estaEnBloque=true;
            toRet= bloqueActual.chequearExistencia(id).getTipo();
        }

            if(!unidadActual.esConstructor() && atributo!=null){
                Metodo metodoActual = (Metodo) unidadActual;
                if(metodoActual.getEnlace().equals("static"))
                    throw new ExcepcionSemantico("No se puede hacer referencia a una variable de instancia desde un contexto estatico", nroLinea, "static");
            }
            if(atributo!=null && atributo.getVisibilidad().equals("private") && !atributo.getClase().getNombre().equals(claseActual.getNombre())){
                throw new ExcepcionSemantico("No se puede hacer referencia a un atributo privado de una clase ancestro, en este caso el atributo privado es "+id+" de la clase ancestro "+claseActual.getAtributo(id).getClase().getNombre()+" y se lo referencia desde la clase "+claseActual.getNombre(),nroLinea,id);
            }
        
        /*
        if(!esIzq && estaEnBloque){
            //quiere decir que lo estamos usando, no asignando
            if(!bloqueActual.estaInicializado(id))
                throw new ExcepcionSemantico("Se quiere utilizar la variable "+id+" pero posiblemente no esta inicializada", nroLinea,id);
        }
        
        
        //Una vez que chequeamos que existe, debemos fijarnos que esta inicializado
        //Luego mandamos a chequear el encadenado si es que existe
        if(encadenado !=null ){
            toRet = encadenado.chequear(toRet,nroLinea, nroColumna);
        }
        */
        return toRet;
        
    }
    
}

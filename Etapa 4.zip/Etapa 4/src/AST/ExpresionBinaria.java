
package AST;


import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Tipo;
import TablaDeSimbolos.TipoBoolean;
import TablaDeSimbolos.TipoInt;
import TablaDeSimbolos.TipoMetodo;


public class ExpresionBinaria extends Expresion{
    private String operador;
    private Expresion ladoIzquierdo;
    private Expresion ladoDerecho;
    
    public ExpresionBinaria(int nroLinea,int nroColumna, String operador) {
        super(nroLinea, nroColumna);
        this.operador=operador;
    }

    public void setLadoIzquierdo(Expresion ladoIzquierdo) {
        this.ladoIzquierdo = ladoIzquierdo;
    }

    public void setLadoDerecho(Expresion ladoDerecho) {
        this.ladoDerecho = ladoDerecho;
    }
    

    
    public Tipo chequear() throws ExcepcionSemantico {
    	
        TipoMetodo tipoLadoIzquierdo= ladoIzquierdo.chequear();
        TipoMetodo tipoLadoDerecho= ladoDerecho.chequear();
        //boolean hayError=false;
        Tipo toRet=null;
        
        if(tipoLadoDerecho.esTipoVoid()){
            throw new ExcepcionSemantico("En la expresion binaria que tiene operador "+operador+" tiene la subexpresion derecha void", nroLinea, operador);
        }
        if(tipoLadoIzquierdo.esTipoVoid()){
            throw new ExcepcionSemantico("En la expresion binaria que tiene operador "+operador+" tiene la subexpresion izquierda void", nroLinea,operador);
        }
        if(operador.equals("O_Suma") || operador.equals("O_Resta") || operador.equals("O_Mult") || operador.equals("O_Div") || operador.equals("O_Mod") || operador.equals("O_Menor") || operador.equals("O_Menorigual") || operador.equals("O_Mayor")|| operador.equals("O_Mayorigual")){
            if(!tipoLadoIzquierdo.esTipoInt()){
               throw new ExcepcionSemantico("En la expresion binaria que tiene operador "+operador+" tiene la subexpresion izquierda de tipo "+tipoLadoIzquierdo.getNombreTipo()+" pero se espera que sea del tipo int", nroLinea, tipoLadoIzquierdo.getNombreTipo()); 
            }
            if(!tipoLadoDerecho.esTipoInt()){
                throw new ExcepcionSemantico("En la expresion binaria que tiene operador "+operador+" tiene la subexpresion derecha de tipo "+tipoLadoDerecho.getNombreTipo()+" pero se espera que sea del tipo int", nroLinea, tipoLadoDerecho.getNombreTipo());
            }
            if(operador.equals("O_Menor") || operador.equals("O_Menorigual") || operador.equals("O_Mayor")|| operador.equals("O_Mayorigual")){
                toRet= new TipoBoolean();
            }else    
                toRet= new TipoInt();
        }
        
        if(operador.equals("O_Or") || operador.equals("O_And")){
            if(!tipoLadoIzquierdo.esTipoBoolean()){
               throw new ExcepcionSemantico("En la expresion binaria que tiene operador "+operador+" tiene la subexpresion izquierda de tipo "+tipoLadoIzquierdo.getNombreTipo()+" pero se espera que sea del tipo boolean", nroLinea, tipoLadoIzquierdo.getNombreTipo()); 
            }
            if(!tipoLadoDerecho.esTipoBoolean()){
                throw new ExcepcionSemantico("En la expresion binaria que tiene operador "+operador+" tiene la subexpresion derecha de tipo "+tipoLadoDerecho.getNombreTipo()+" pero se espera que sea del tipo boolean", nroLinea, tipoLadoDerecho.getNombreTipo());
            }
            toRet= new TipoBoolean();
        }
        if(operador.equals("O_Comparacion") || operador.equals("O_Distinto")){
            Tipo tLadoIzq= (Tipo)tipoLadoIzquierdo;
            Tipo tLadoDer= (Tipo) tipoLadoDerecho;
            if((!tLadoIzq.esCompatible(tLadoDer)) && (!tLadoDer.esCompatible(tLadoIzq)))
                throw new ExcepcionSemantico("En la expresion binaria que tiene operador "+operador+" tiene la subexpresion derecha de tipo "+tipoLadoDerecho.getNombreTipo()+" y la subexpresion izquierda de tipo "+tipoLadoIzquierdo.getNombreTipo()+" y las mismas no conforman", nroLinea, tipoLadoIzquierdo.getNombreTipo());
            toRet= new TipoBoolean();
        }
        return toRet;
    }
    
}

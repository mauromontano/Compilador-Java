
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.TipoMetodo;

import java.util.HashSet;
import java.util.Set;


public class If extends Sentencia{
    private Expresion condicion;
    private Sentencia sentencia;
    private Sentencia sentenciaElse;
    private Set<String> inicializadas;
    
    public If(int nroLinea){
        this.nroLinea=nroLinea;
        inicializadas= new HashSet<String>();
    }
    
    
    public boolean hayReturn(){
        boolean toRet=sentencia.hayReturn();
        if(sentenciaElse!=null)
            toRet= toRet && sentenciaElse.hayReturn();
        else
            toRet=false;
        return toRet;
    }
    
   
    
    public void setCondicion(Expresion condicion){
        this.condicion=condicion;
    }
    
    public void setSentencia(Sentencia sentencia){
        this.sentencia=sentencia;
    }
    
    public void setSentenciaElse(Sentencia sentenciaElse){
        this.sentenciaElse=sentenciaElse;
    }
    
    
    public Set<String> getInicializadas(){
        return inicializadas;
    }
    
    
    public void chequear() throws ExcepcionSemantico {
        TipoMetodo t=condicion.chequear();
        if(!t.esTipoBoolean()){
            throw new ExcepcionSemantico("La condicion debe ser de un tipo booleano", condicion.getNroLinea(), t.getNombreTipo());
        }
        sentencia.chequear();
        if(sentenciaElse!=null){
            sentenciaElse.chequear();
            Set<String> init1= sentencia.getInicializadas();
            Set<String> init2= sentenciaElse.getInicializadas();
            for(String str: init1){
                if(init2.contains(str))
                    inicializadas.add(str);
            }
        }
    }
    
   
}


package AST;


public abstract class Literal extends Expresion{
    
	protected String id;
    
    public Literal(int nroLinea, int nroColumna, String id) {
        super(nroLinea, nroColumna);
        this.id=id; 
    }
    
}

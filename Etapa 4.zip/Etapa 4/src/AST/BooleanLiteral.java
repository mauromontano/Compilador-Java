
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.TipoBoolean;
import TablaDeSimbolos.TipoMetodo;


public class BooleanLiteral extends Literal{

    public BooleanLiteral(int nroLinea, int nroColumna, String id) {
        super(nroLinea, nroColumna, id);
    }

    
    public TipoMetodo chequear() throws ExcepcionSemantico {
         return new TipoBoolean();
    }
    
}

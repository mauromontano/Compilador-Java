
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Clase;
import TablaDeSimbolos.Metodo;
import TablaDeSimbolos.TipoMetodo;
import TablaDeSimbolos.Unidad;

import java.util.ArrayList;


public class AccesoMetodo extends Primario{
    private String metodo;
    private Clase claseActual;
    private Unidad unidadActual;
    private ArrayList<Expresion> parametros;

    public AccesoMetodo(String metodo, Clase clase, ArrayList<Expresion> parametros,Unidad unidadActual, int nroLinea, int nroColumna) {
        super(nroLinea,nroColumna,metodo);
        this.metodo = metodo;
        this.claseActual = clase;
        this.unidadActual=unidadActual;
        this.parametros = parametros;
    }

    
    public TipoMetodo chequear() throws ExcepcionSemantico {
        TipoMetodo toRet =null;
        Metodo metodoLlamado= claseActual.getMetodo(metodo);
        if(metodoLlamado==null)
            throw new ExcepcionSemantico("No existe el metodo "+metodo+" en la clase "+claseActual.getNombre(), nroLinea, metodo);

        if(!unidadActual.esConstructor()){
            Metodo metodoActual= (Metodo)unidadActual;
            if(metodoActual.getEnlace().equals("static") && !metodoLlamado.getEnlace().equals("static"))
                throw new ExcepcionSemantico("No se puede llamar al metodo "+metodo+" desde un contexto estatico", nroLinea, metodo);
        }
        metodoLlamado.parametrosCompatible(parametros, nroLinea, nroColumna);
        toRet= metodoLlamado.getTipoRetorno();
        if(encadenado!=null){
            if(toRet.esTipoVoid()){
                throw new ExcepcionSemantico("El metodo "+metodo+" no tiene valor de retorno porque es void", nroLinea, metodo);
            }
            toRet=encadenado.chequear(metodoLlamado.getTipoRetorno(),nroLinea, nroColumna);
        }
        else
            toRet=metodoLlamado.getTipoRetorno();
        return toRet;
    }
    
    
}


package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Clase;
import TablaDeSimbolos.Metodo;
import TablaDeSimbolos.TipoClase;
import TablaDeSimbolos.TipoMetodo;
import TablaDeSimbolos.Unidad;


public class AccesoThis extends Primario{
    private Clase claseActual;
    private Unidad unidadActual;
    
    public AccesoThis(int nroLinea, int nroColumna, Clase claseActual, Unidad unidadActual, String id) {
        super(nroLinea, nroColumna,id);
        this.claseActual=claseActual;
        this.unidadActual=unidadActual;
    }

    
    public TipoMetodo chequear() throws ExcepcionSemantico {
        if(!unidadActual.esConstructor()){
            Metodo metodoActual= (Metodo) unidadActual;
            if(metodoActual.getEnlace().equals("static")){
                throw new ExcepcionSemantico("No se puede hacer referencia a this desde un contexto estatico", nroLinea,"static");
            }
        }
        return new TipoClase(claseActual.getNombre());
    }
    
}

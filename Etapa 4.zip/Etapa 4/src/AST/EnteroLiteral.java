package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.TipoInt;
import TablaDeSimbolos.TipoMetodo;


public class EnteroLiteral extends Literal{

    public EnteroLiteral(int nroLinea, int nroColumna,String id) {
        super(nroLinea, nroColumna, id);
    }

    
    public TipoMetodo chequear() throws ExcepcionSemantico {
        return new TipoInt();
    }
    
}

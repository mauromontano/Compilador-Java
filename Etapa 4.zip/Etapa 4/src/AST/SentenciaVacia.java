package AST;


public class SentenciaVacia extends Sentencia{
    public SentenciaVacia(int nroLinea, int nroColumna){
        super();
        this.nroLinea=nroLinea;
        this.nroColumna=nroColumna;
    }
    
    public void chequear() {
    }
    
}

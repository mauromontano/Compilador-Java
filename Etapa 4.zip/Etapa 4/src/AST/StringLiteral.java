package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.TipoMetodo;
import TablaDeSimbolos.TipoString;

public class StringLiteral extends Literal{

    public StringLiteral(int nroLinea, int nroColumna, String id) {
        super(nroLinea, nroColumna, id);
    }

    
    public TipoMetodo chequear() throws ExcepcionSemantico {
        return new TipoString();
    }
    
}

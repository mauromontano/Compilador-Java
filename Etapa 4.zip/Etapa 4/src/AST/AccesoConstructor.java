
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Clase;
import TablaDeSimbolos.Constructor;
import TablaDeSimbolos.TipoClase;
import TablaDeSimbolos.TipoMetodo;

import java.util.ArrayList;

public class AccesoConstructor extends Primario{
    private String constructor;
    private ArrayList<Expresion> parametros;

    public AccesoConstructor(String constructor, ArrayList<Expresion> parametros,  int nroLinea, int nroColumna) {
        super(nroLinea,nroColumna,constructor);
        this.constructor = constructor;
        this.parametros = parametros;
    }

    
    public TipoMetodo chequear() throws ExcepcionSemantico {
        //Primero tenemos que chequear que exista la clase con el nombre del constructor
        TipoMetodo toRet=null;
        Clase claseConstructor= Modulos.AnalizadorSintactico.tablaSimbolos.getClase(constructor);
        if(claseConstructor==null)
            throw new ExcepcionSemantico("Se quiere crear una instancia de la clase "+constructor+" pero la misma no existe", nroLinea, constructor);
        Constructor constructorVerdadero= claseConstructor.getMiConstructor();
        constructorVerdadero.parametrosCompatible(parametros, nroLinea, nroColumna);
        toRet= new TipoClase(constructor);
        if(encadenado!=null)
            toRet= encadenado.chequear(new TipoClase(constructor),nroLinea,nroColumna);
        return toRet;
    }
    
    
    
    
}

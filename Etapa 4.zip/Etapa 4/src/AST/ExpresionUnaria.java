
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Tipo;
import TablaDeSimbolos.TipoBoolean;
import TablaDeSimbolos.TipoInt;
import TablaDeSimbolos.TipoMetodo;


public class ExpresionUnaria extends Expresion{
    private String operador;
    private Expresion unaria;
    /*
    public ExpresionUnaria(int nroLinea,int nroColumna, Expresion unaria) {
        super(nroLinea, nroColumna);
        //this.operador = operador;
        this.unaria=unaria;
    }*/
    
    public ExpresionUnaria(String operador,int nroLinea,int nroColumna, Expresion unaria) {
        super(nroLinea, nroColumna);
        this.operador = operador;
        this.unaria=unaria;
    }

    public void setUnaria(Expresion unaria) {
        this.unaria = unaria;
    }

    public void setOperador(String operador) {
        this.operador=operador;
    }
    
    public Tipo chequear() throws ExcepcionSemantico {
        TipoMetodo tipoUnaria= unaria.chequear();
        Tipo toRet=null;
        if(tipoUnaria.esTipoVoid()){
            throw new ExcepcionSemantico("En la expresion unaria que tiene el operador "+operador+" no debe tener una expresion void", nroLinea, operador);
        }
        if(operador.equals("O_Suma")||operador.equals("O_Resta")){
            if(!tipoUnaria.esTipoInt()){
                throw new ExcepcionSemantico("En la expresion unaria que tiene el operador "+operador+" debe tener una expresion de tipo int", nroLinea, operador);
            }
            toRet= new TipoInt();
        }
        if(operador.equals("O_Not")){
            if(!tipoUnaria.esTipoBoolean()){
                throw new ExcepcionSemantico("En la expresion unaria que tiene negacion debe tener una expresion de tipo boolean", nroLinea, operador);
            }
            
            toRet = new TipoBoolean();
        }
        return toRet; 
    }
    
    
}

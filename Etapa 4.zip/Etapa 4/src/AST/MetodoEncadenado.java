
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Clase;
import TablaDeSimbolos.Metodo;
import TablaDeSimbolos.TipoMetodo;

import java.util.ArrayList;


public class MetodoEncadenado extends Encadenado{
	
    private ArrayList<Expresion> argumentos;
    
    public MetodoEncadenado(String id, ArrayList<Expresion> expresiones) {
        super(id);
        this.argumentos=expresiones;
    }

    
    public TipoMetodo chequear(TipoMetodo anterior,int nroLinea, int nroColumna) throws ExcepcionSemantico {
        TipoMetodo toRet= null;
        //El tipo anterior debe ser un tipo clase
        if(!anterior.esTipoClase()){
            throw new ExcepcionSemantico("No se puede obtener un metodo desde un tipo "+anterior.getNombreTipo()+", en este caso el metodo es "+id, nroLinea, anterior.getNombreTipo());
        }
        //Necesito saber si el metodo existe en la clase y ademas es publico
        Clase claseAnterior = Modulos.AnalizadorSintactico.tablaSimbolos.getClase(anterior.getNombreTipo());
        Metodo metodoBuscado= claseAnterior.getMetodo(id);
        if(metodoBuscado==null){
            throw new ExcepcionSemantico("El metodo "+id+" no existe en la clase "+claseAnterior.getNombre(), nroLinea, claseAnterior.getNombre());
        }
        
        //necesito chequear que tengan una signatura compatible
        metodoBuscado.parametrosCompatible(argumentos,nroLinea,nroColumna);
        
        if(encadenado!=null){
            if(metodoBuscado.getTipoRetorno().esTipoVoid()){
                throw new ExcepcionSemantico("El metodo "+id+" de la clase "+claseAnterior.getNombre()+" no tiene valor de retorno porque es void", nroLinea,claseAnterior.getNombre());
            }
            toRet=encadenado.chequear(metodoBuscado.getTipoRetorno(),nroLinea, nroColumna);
        }
        else
            toRet=metodoBuscado.getTipoRetorno();
        return toRet;
    }
    
}

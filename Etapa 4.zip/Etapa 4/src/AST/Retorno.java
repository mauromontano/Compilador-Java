
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Metodo;
import TablaDeSimbolos.Tipo;
import TablaDeSimbolos.TipoMetodo;
import TablaDeSimbolos.Unidad;


public class Retorno extends Sentencia{
    private Expresion retornado;
    private Unidad unidadContenida;
    
    
    public Retorno(int nroLinea , Unidad unidadContenida){
        this.nroLinea=nroLinea;
        this.unidadContenida=unidadContenida;
    }
    
    
    public boolean hayReturn(){
        return true;
    }
    
    public void setExpresion(Expresion retornado){
        this.retornado=retornado;
    }
    
    
    public void chequear() throws ExcepcionSemantico {
        //Primero chequeamos que sea una expresion valida
        
        if(unidadContenida.esConstructor()){
            if(retornado!=null)
                throw new ExcepcionSemantico("No se espera un retorno en un constructor", nroLinea, unidadContenida.getNombre());
        }else{
            Metodo metodoContenido= (Metodo)unidadContenida;
            TipoMetodo tipoMetodoContenido=metodoContenido.getTipoRetorno();
            boolean esVoid=tipoMetodoContenido.esTipoVoid();
            if(esVoid && retornado!=null){
                throw new ExcepcionSemantico("No se espera un retorno en un metodo void",nroLinea,metodoContenido.getNombre());
            }
            if(!esVoid && retornado==null){
                throw new ExcepcionSemantico("Se espera un retorno de tipo "+tipoMetodoContenido.getNombreTipo(),nroLinea, metodoContenido.getNombre());
            }
            if(retornado!=null){
                //A esta altura sabemos que si retornado!=null o !esVoid
                Tipo tipoRetornado=(Tipo)retornado.chequear();
                Tipo tipoMetodo= (Tipo) tipoMetodoContenido;
                if(!tipoRetornado.esCompatible(tipoMetodo)){
                    throw new ExcepcionSemantico("El tipo retornado es incompatible con el tipo esperado ya que "+tipoRetornado.getNombreTipo()+" no puede ser convertido a "+tipoMetodo.getNombreTipo(),nroLinea,tipoRetornado.getNombreTipo());
                }
            }

        }
    }
    
    
}

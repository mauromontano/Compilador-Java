package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Atributo;
import TablaDeSimbolos.Clase;
import TablaDeSimbolos.TipoMetodo;


public class VarEncadenado extends Encadenado{

    public VarEncadenado(String id) {
        super(id);
    }

    
    public TipoMetodo chequear(TipoMetodo anterior,int nroLinea, int nroColumna) throws ExcepcionSemantico {
        //TipoMetodo toRet= null;
        //El tipo anterior debe ser un tipo clase
        if(!anterior.esTipoClase()){
            throw new ExcepcionSemantico("No se puede obtener un atributo desde un tipo "+anterior.getNombreTipo()+", en este caso el atributo es "+id, nroLinea, id);
        }
        //Debemos saber si existe ese atributo publico en la clase anterior
        Clase claseAnterior = Modulos.AnalizadorSintactico.tablaSimbolos.getClase(anterior.getNombreTipo());
        Atributo atributoActual=claseAnterior.getAtributo(id);
        if(atributoActual==null)
            throw new ExcepcionSemantico("No existe el atributo "+id+" en la clase "+claseAnterior.getNombre(), nroLinea, id);
        if(!atributoActual.getVisibilidad().equals("public"))
            throw new ExcepcionSemantico("El atributo "+id+" de la clase "+claseAnterior.getNombre()+" debe ser publico", nroLinea, id);
       
        if(encadenado==null)
            return atributoActual.getTipo();
        else
            return encadenado.chequear(atributoActual.getTipo(),nroLinea,nroColumna);
        
    }
    
}

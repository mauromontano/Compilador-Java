
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Clase;
import TablaDeSimbolos.Unidad;
import TablaDeSimbolos.Variable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


public class Bloque extends Sentencia{
    private ArrayList<Sentencia> sentencias;
    private Map<String,Variable> variables;
    private Bloque bloqueSuperior;
    @SuppressWarnings("unused")
	private Unidad unidadActual;
    @SuppressWarnings("unused")
	private Clase claseActual;
    private Set<String> inicializados;
    
    public Bloque(Bloque bloqueSuperior, Unidad unidadActual, Clase claseActual){
        sentencias= new ArrayList<Sentencia>();
        variables = new HashMap<String,Variable>();
        inicializados= new HashSet<String>();
        this.bloqueSuperior=bloqueSuperior;
        this.unidadActual=unidadActual;
        this.claseActual=claseActual;
    }
    
    
    public void eliminarDeclaracionVariable(String var){
        variables.remove(var);
    }
    
    public void insertarSentencia(Sentencia s){
        sentencias.add(s);
    }
    
    public Variable getVariable(String str){
        return variables.get(str);
    }
    
    public void insertarVariable(Variable v) {
        //No se hace chequeo porque el chequeo ya se hace en la declaracion de variables
        variables.put(v.getNombre(), v);
    }

    public Bloque getBloqueSuperior() {
        return bloqueSuperior;
    }
    
    public boolean hayReturn(){
        boolean toRet=false;
        for(int i=0;i <sentencias.size() && !toRet ; i++){
            toRet=sentencias.get(i).hayReturn();
        }
        return toRet;
    }
 
    
    
    public Variable chequearExistencia(String nombreVariable){
        Variable toRet= null;
        if(variables.containsKey(nombreVariable))
            toRet=variables.get(nombreVariable);
        else{
            if(bloqueSuperior!=null)
                toRet= bloqueSuperior.chequearExistencia(nombreVariable);
        }
        return toRet;
    }
    
      //Determina si la variable que tiene el nombre pasado por parametro esta inicializada en el bloque actual o en los superiores
    
    public boolean estaInicializado(String nombreVariable){
        boolean toRet=false;
        if(inicializados.contains(nombreVariable))
            toRet= true;
        else{
            if(bloqueSuperior!=null)
                toRet= bloqueSuperior.estaInicializado(nombreVariable);
        }
        return toRet;
    }
    
     
    //Chequea cada una de las sentencias del bloque
    
    public void chequear() throws ExcepcionSemantico {
        boolean hayReturn=false;
        for(int i=0; i<sentencias.size();i++){
            if(hayReturn)
                throw new ExcepcionSemantico("Esta sentencia es inalcanzable", sentencias.get(i).getNroLinea(),"");
            sentencias.get(i).chequear();
            Set<String> init2= sentencias.get(i).getInicializadas();
            if(sentencias.get(i).hayReturn())
                hayReturn=true;
            for(String str: init2)
                inicializados.add(str);
        }
    }
    
    
    public Set<String> getInicializadas(){
        return inicializados;
    }
    
   
}

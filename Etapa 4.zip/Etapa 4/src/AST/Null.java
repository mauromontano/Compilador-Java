package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.TipoMetodo;
import TablaDeSimbolos.TipoNull;

public class Null extends Literal{

    public Null(int nroLinea, int nroColumna) {
        super(nroLinea, nroColumna, "null");
    }

    
    public TipoMetodo chequear() throws ExcepcionSemantico {
        return new TipoNull();
    }
    
}

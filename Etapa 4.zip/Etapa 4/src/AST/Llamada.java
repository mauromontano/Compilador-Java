package AST;

import Excepciones.ExcepcionSemantico;

public class Llamada extends Sentencia{

	Primario primario;
    
    public Llamada(int nroLinea, int nroColumna, Primario p) {
        this.nroLinea=nroLinea;
        this.primario= p;
        this.nroColumna=nroColumna;
    }

    
    
    public void chequear() throws ExcepcionSemantico {
        primario.chequear();
    }
}

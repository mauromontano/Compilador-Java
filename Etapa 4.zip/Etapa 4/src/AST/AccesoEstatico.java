
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Clase;
import TablaDeSimbolos.Metodo;
import TablaDeSimbolos.TipoMetodo;

import java.util.ArrayList;


public class AccesoEstatico extends Primario{
    private String clase;
    private ArrayList<Expresion> parametros;
    private String metodo;

    public AccesoEstatico(String clase, ArrayList<Expresion> parametros, String metodo,  int nroLinea, int nroColumna) {
        super(nroLinea, nroColumna,clase);
        this.clase = clase;
        this.parametros = parametros;
        this.metodo = metodo;
    }

    
    public TipoMetodo chequear() throws ExcepcionSemantico {
        //Ya sabemos que existe la clase
        Clase claseLlamada= Modulos.AnalizadorSintactico.tablaSimbolos.getClase(clase);
        TipoMetodo toRet=null;
        if(claseLlamada==null)
            throw new ExcepcionSemantico("La clase "+clase+" no esta definida", nroLinea, clase);
        else
        {
            Metodo metodoLlamado= claseLlamada.getMetodo(metodo);
            if(metodoLlamado == null){
                throw new ExcepcionSemantico("No existe el metodo "+metodo+" en la clase "+clase, nroLinea, metodo);
            }
            if(!metodoLlamado.getEnlace().equals("static")){
                throw new ExcepcionSemantico("El metodo "+metodo+" en la clase "+clase+" no es estatico", nroLinea, metodo);
            }
            
            
            metodoLlamado.parametrosCompatible(parametros, nroLinea, nroColumna);
            toRet=metodoLlamado.getTipoRetorno();
        }

        return toRet;
    }
    
}

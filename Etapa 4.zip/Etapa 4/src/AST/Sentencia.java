package AST;

import Excepciones.ExcepcionSemantico;
import java.util.HashSet;
import java.util.Set;



public abstract class Sentencia {
    protected int nroLinea;
    protected int nroColumna;
    
    public abstract void chequear() throws ExcepcionSemantico;

    public void setNroLinea(int nroLinea) {
        this.nroLinea = nroLinea;
    }

    public int getNroLinea() {
        return nroLinea;
    }
    
    public void setNroColumna(int nroCol) {
        nroColumna = nroCol;
    }

    public int getNroColumna() {
        return nroColumna;
    }
    
    public boolean hayReturn(){
        return false;
    }
    public boolean esDeclaracion(){
        return false;
    }
   public Set<String> getInicializadas(){
       return new HashSet<String>();
   }
    
}

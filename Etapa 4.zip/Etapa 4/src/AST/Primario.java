
package AST;


public abstract class Primario extends Expresion{
    protected Encadenado encadenado;
    private String id;

    public Primario(int nroLinea, int nroColumna, String id) {
        super(nroLinea, nroColumna);
        this.id= id;

    }

    public void setEncadenado(Encadenado encadenado) {
        this.encadenado = encadenado;
    }
    
    public Encadenado getEncadenado(){
        return encadenado;
    }
	
    public boolean tieneEncadenado(){
        return encadenado!=null;
    }
    
    public String getNombreVariable(){
        return id;
    }
    
    
}

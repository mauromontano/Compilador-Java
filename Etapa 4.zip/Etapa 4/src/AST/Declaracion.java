
package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.Tipo;
import TablaDeSimbolos.Unidad;
import TablaDeSimbolos.Variable;

import java.util.ArrayList;


public class Declaracion extends Sentencia{
    private ArrayList<Variable> declaracionVariables;
    private Bloque bloqueActual;
    private Unidad unidadActual;
    
    public Declaracion(int nroLinea, Bloque bloqueActual, Unidad unidadActual){
        this.nroLinea=nroLinea;
        this.bloqueActual=bloqueActual;
        this.unidadActual=unidadActual;
        declaracionVariables = new ArrayList<Variable>();
    }
    
    public boolean esDeclaracion(){
        return true;
    }
    
    
     //Agrega la variable a la declaracion de variables
    
    public void insertarVariable(Variable v) throws ExcepcionSemantico{
        //boolean existe=false;
        for(int i=0;i<declaracionVariables.size(); i++){
            if(declaracionVariables.get(i).getNombre().equals(v.getNombre()))
                throw new ExcepcionSemantico("La variable declarada "+v.getNombre()+" ya fue declarada en la misma linea", v.getLinea(), v.getNombre());
            
        }
       Variable variableBloque= bloqueActual.chequearExistencia(v.getNombre());
       if(variableBloque!=null){
           throw new ExcepcionSemantico("La variable declarada "+v.getNombre()+" ya fue declarada en la linea "+variableBloque.getLinea(),v.getLinea(), v.getNombre());
       }
       Variable variableParametro = unidadActual.getParametro(v.getNombre());
       if(variableParametro!=null){
           throw new ExcepcionSemantico("La variable declarada "+v.getNombre()+" ya se encuentra en un parametro de la misma unidad (la unidad "+unidadActual.getNombre()+")", v.getLinea(), v.getNombre());
       }
       declaracionVariables.add(v);
    }
    
    
     //Se utiliza para el caso especial en que la declaracion se encuentra dentro de un if sin bloque, por lo que deben desaparecer las variables declaradas en este if.
    
    public void eliminarVariables(){
        String nombreActual;
        for(int i=0;i<declaracionVariables.size();i++){
            nombreActual=declaracionVariables.get(i).getNombre();
            bloqueActual.eliminarDeclaracionVariable(nombreActual);
        }
    }
    
    
     //Se chequea si el tipo de las variables es de un tipo primitivo o un tipo definido
    
    public void chequear() throws ExcepcionSemantico{
        if(declaracionVariables.size()>0){
            Tipo tipoVariables= declaracionVariables.get(0).getTipo();
            if(!tipoVariables.esTipoPrimitivo()){
                //Deberia ser un tipo definido
                if(!Modulos.AnalizadorSintactico.tablaSimbolos.existeClase(tipoVariables.getNombreTipo())){
                    throw new ExcepcionSemantico("Las variables declaradas no es de un tipo primitivo o de una clase ya definida ya que el tipo "+tipoVariables.getNombreTipo()+" no existe", declaracionVariables.get(0).getLinea(), tipoVariables.getNombreTipo());
                }
            }
        }
    }
    
   
}

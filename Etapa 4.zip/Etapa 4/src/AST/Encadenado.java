
package AST;
import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.TipoMetodo;

public abstract class Encadenado {
    protected Encadenado encadenado;
    protected String id;

    public Encadenado(String id) {
        this.id = id;
    }

    public void setEncadenado(Encadenado encadenado) {
        this.encadenado = encadenado;
    }

    public Encadenado getEncadenado() {
        return encadenado;
    }
    
    public String getId() {
    	return id;
    }
    
    public abstract TipoMetodo chequear(TipoMetodo anterior,int nroLinea,int nroColumna) throws ExcepcionSemantico;
}


package AST;

import Excepciones.ExcepcionSemantico;
import TablaDeSimbolos.TipoMetodo;


public abstract class Expresion {
    protected int nroLinea;
    protected int nroColumna;

    public Expresion(int nroLinea, int nroColumna) {
        this.nroLinea = nroLinea;
        this.nroColumna = nroColumna;
    }
    public int getNroLinea(){
        return nroLinea;
    }
    
    public int getNroColumna() {
    	return nroColumna;
    }
    public abstract TipoMetodo chequear() throws ExcepcionSemantico;
}

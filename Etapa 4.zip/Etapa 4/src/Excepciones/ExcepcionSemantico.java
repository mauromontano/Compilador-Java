package Excepciones;

@SuppressWarnings("serial")
public class ExcepcionSemantico extends Excepcion{
    private final String error;
    private final int nroLinea;
    //private final int nroColumna;
    private final String lexema;
    
    
    public ExcepcionSemantico(String error, int linea, String lexema) {
    	this.error=error;
    	this.nroLinea=linea;
		//this.nroColumna = 0;
        this.lexema= lexema;
	}
    
    
    public String getError() { 
    	System.out.println("Error semantico en linea "+nroLinea+": "+error);
        return "[Error:"+lexema+"|"+nroLinea+"]";      
    }
    
	
	
}

package Excepciones;

public abstract class Excepcion extends Exception{
		private static final long serialVersionUID = 1L;

		public abstract String getError();

}

package TablaDeSimbolos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import AST.Bloque;
import AST.Expresion;
import Estructuras.Token;
import Excepciones.ExcepcionSemantico;

public abstract class Unidad {
	
    protected Map<String,Variable> parametros;
    //Hay que agregar la lista ordenada
    protected Token id;
    protected ArrayList<Tipo> tiposOrdenados;
    protected ArrayList<String> nombresArgumentos;
    protected Bloque bloque;

    
    
    public Unidad (Token id ){
        this.id=id;
        parametros = new HashMap<String,Variable>();
        tiposOrdenados= new ArrayList<Tipo>();
        nombresArgumentos= new ArrayList<String>();
        bloque=null;

    }
    
    public abstract boolean esConstructor();
    
    public abstract void parametrosCompatible(ArrayList<Expresion> parametrosActuales, int nroLinea, int nroColumna) throws ExcepcionSemantico;
    
    public abstract void chequear() throws ExcepcionSemantico;
    
    
    public void setBloque(Bloque b){
        bloque=b;
    }
    
    public Bloque getBloque() {
        return bloque;
    }

    
    protected Token getId(){
        return id;
    }
    
    public int getLinea(){
        return id.getLinea();
    }

    public int getColumna(){
        return id.getColumna();
    }

    
    public String getNombre(){
        return id.getLexema();
    }

    
    public String getNombreUnidad(){
        return "Metodo"; //Me salva de errores
    }
    
    public void insertarArgumento(Variable v) throws ExcepcionSemantico{
        //Chequeamos que el nombre del par�metro no sea el mismo que otro
        if(parametros.containsKey(v.getId().getLexema())){
            throw new ExcepcionSemantico("En el "+getNombreUnidad()+" "+id.getLexema()+" el parametro "+v.getId().getLexema()+" esta repetido.", v.getId().getLinea(),v.getId().getLexema());
        }
        parametros.put(v.getId().getLexema(),v);
        tiposOrdenados.add(v.getTipo());
        nombresArgumentos.add(v.getId().getLexema());
    }
    
    public boolean mismoTipo(int index, Tipo aComparar){
        boolean toRet=false;
        if(tiposOrdenados.get(index).esTipo(aComparar))
            toRet=true;
        return toRet;
    }
    
    public String getNombreArgumento(int index){
        return nombresArgumentos.get(index);
    }
    
    public int cantidadParametros(){
        return  parametros.size();
    }
    
    public void chequearTiposArgumentos() throws ExcepcionSemantico{
        for(Variable v: parametros.values()){
            if(!v.esTipoValido()){
               throw new ExcepcionSemantico("El tipo "+v.getTipo().getNombreTipo()+" definido en el parametro "+v.getId().getLexema()+" no existe.", id.getLinea(), v.getId().getLexema());

            }
        }
    }
    
    public ArrayList<Tipo> getTiposOrdenados(){
        return tiposOrdenados;
    }
    
    public Variable getParametro(String s){
        return parametros.get(s);
    }
    

}
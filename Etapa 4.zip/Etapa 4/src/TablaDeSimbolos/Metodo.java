package TablaDeSimbolos;

import java.util.ArrayList;

import AST.Expresion;
import Estructuras.Token;
import Excepciones.ExcepcionSemantico;

public class Metodo extends Unidad{
	
	private final String enlace;
    private TipoMetodo tipoRetorno;
    private Clase claseActual;

    public Metodo(Token id, String enlace, TipoMetodo tipoRetorno, Clase claseActual) {
        super(id);
        this.enlace = enlace;
        this.tipoRetorno = tipoRetorno;
        this.claseActual=claseActual;

    }
    
    public Clase getClaseActual() {
        return claseActual;
    }
    
    public Variable getParametro(int indice){
		
    	Variable toReturn = null;
	
				for(Variable p : parametros.values()){
					
					if(p.getId().getLinea()==indice)
						toReturn = p;
				}
			
		
		return toReturn;
	}

    public String getEnlace() {
        return enlace;
    }
    
    
    public String getNombreUnidad(){
        return "metodo";
    }
    
    public boolean mismoNombre(Metodo m){
        return m.getId().getLexema().equals(id.getLexema());
    }
    
    public void chequearTipoRetornoValido() throws ExcepcionSemantico{
        if(!tipoRetorno.esTipoValido())
            throw new ExcepcionSemantico("El tipo de retorno del metodo "+id.getLexema()+" no existe.", id.getLinea(), id.getLexema());
    }
        
    public TipoMetodo getTipoRetorno(){
        return tipoRetorno;
    }
    
 // Chequea si los par�metros actuales son compatibles con los par�metros formales
    
    public void parametrosCompatible(ArrayList<Expresion> parametrosActuales, int nroLinea, int nroColumna) throws ExcepcionSemantico{
        //Primero me fijo si la cantidad de par�metros es la misma
        if(parametrosActuales.size()!=nombresArgumentos.size())
            throw new ExcepcionSemantico("Se esta queriendo llamar al metodo "+getNombre()+" pero la cantidad de parametros actuales es "+parametrosActuales.size()+" y deberia ser "+nombresArgumentos.size(), nroLinea, getNombre());
        for(int i=0;i<parametrosActuales.size();i++){
            TipoMetodo tipoEvaluadoArgumento= parametrosActuales.get(i).chequear();
            if(tipoEvaluadoArgumento.esTipoVoid()){
                throw new ExcepcionSemantico("El parametro actual de la posicion "+(i+1)+" del metodo "+getNombre()+" no debe ser void", nroLinea, getNombre());
            }
            if(!tipoEvaluadoArgumento.esCompatible(tiposOrdenados.get(i))){
                if(tiposOrdenados.get(i).esTipoClase()){
                    throw new ExcepcionSemantico("El tipo del parametro actual en la posicion "+(i+1)+" de la llamada al metodo "+getNombre()+" es "+tipoEvaluadoArgumento.getNombreTipo()+" pero deberia ser del tipo "+tiposOrdenados.get(i).getNombreTipo()+" o alguno de sus descendientes si es que los tuviese", nroLinea, tipoEvaluadoArgumento.getNombreTipo());
                }else
                    throw new ExcepcionSemantico("El tipo del parametro actual en la posicion "+(i+1)+" de la llamada al metodo "+getNombre()+" es "+tipoEvaluadoArgumento.getNombreTipo()+" pero deberia ser del tipo "+tiposOrdenados.get(i).getNombreTipo(), nroLinea, tipoEvaluadoArgumento.getNombreTipo());
            }
        }
    }
    
    public void chequear() throws ExcepcionSemantico{
        
        bloque.chequear();
        if(!getTipoRetorno().esTipoVoid()){
            //quiere decir que en ese bloque debe haber al menos un return
            if(!bloque.hayReturn())
                throw new ExcepcionSemantico("En el metodo "+getNombre()+" falta la sentencia de retorno", getLinea(), getNombre());
        }
        
    }
    
    
    public boolean esConstructor() {
        return false;
    }
    
    
    /**
     * Chequea la signatura del metodo de esta clase (que es de la superclase) con el metodo pasado por parametro (que es de la subclase)
     */
    public void chequearSignatura(Metodo m) throws ExcepcionSemantico{

    	boolean hayErrorSublcase=false;
        String toErrSubclase="Se esta queriendo redefinir el metodo "+m.getId().getLexema()+" pero el mismo en la subclase debe tener:\n";
        
        if(!tipoRetorno.esTipo(m.getTipoRetorno())){
            toErrSubclase+="* El tipo de retorno "+tipoRetorno.getNombreTipo()+"\n";
            hayErrorSublcase=true;
        }
        
        if(!enlace.equals(m.getEnlace())){
            toErrSubclase+="* El modificador "+enlace+"\n";
            hayErrorSublcase=true;
         }
       
        if(m.cantidadParametros()!=parametros.size()){
            toErrSubclase+="* "+cantidadParametros()+" parametros\n";
            hayErrorSublcase=true;
        }
        
        if(m.cantidadParametros()>=parametros.size()){
            int index=0;
            for(Tipo tipoSuper: tiposOrdenados){
                if(!m.mismoTipo(index, tipoSuper)){
                    toErrSubclase+="* El tipo de "+m.getNombreArgumento(index)+" debe ser "+tipoSuper.getNombreTipo()+"\n";
                    hayErrorSublcase=true;
                }
                index=index+1;
            }
            }else{
                ArrayList<Tipo> tiposOrdenadosSubclase= m.getTiposOrdenados();
                int index=0;
                for(@SuppressWarnings("unused") Tipo tipoSub: tiposOrdenadosSubclase){
                    if(!m.mismoTipo(index, tiposOrdenados.get(index))){
                        toErrSubclase+="* El tipo de "+m.getNombreArgumento(index)+" debe ser "+tiposOrdenados.get(index).getNombreTipo()+"\n";
                        hayErrorSublcase=true;
                    }
                    index=index+1;
                }
            }
        
       if(hayErrorSublcase)
             throw new ExcepcionSemantico(toErrSubclase, m.getId().getLinea(), m.getId().getLexema());
        
    }
    
    public void puedeSobreEscribirse(Metodo m) throws ExcepcionSemantico{
		
		if(!enlace.equals(m.getEnlace())) 
				throw new ExcepcionSemantico(" El metodo \""+this.getId().getLexema()+"\" no se puede redefinir porque su forma es distinta",m.getId().getLinea(),
					this.getId().getLexema());
		
		if(!tipoRetorno.getNombreTipo().equals(m.getTipoRetorno().getNombreTipo()))
			throw new ExcepcionSemantico(" El metodo \""+this.getId().getLexema()+"\" no se puede redefinir porque su tipo de retorno es distinto",m.getId().getLinea(),
					this.getId().getLexema());
		
		if(parametros.size()!=m.cantidadParametros())
			
			throw new ExcepcionSemantico(" El metodo \""+this.getId().getLexema()+"\" no se puede redefinir porque su cantidad de parametros es distinta",m.getId().getLinea(),
					this.getId().getLexema());
		
		
		for(int i=0;i<parametros.size();i++){
			
			if(!this.getParametro(i).getTipo().getNombreTipo().equals(m.getParametro(i).getTipo().getNombreTipo()))
				
				throw new ExcepcionSemantico(" El metodo \""+this.getId().getLexema()+"\" no se puede redefinir, el parametro numero "+(i+1)+" no matchea. Se esperaba un Parametro de tipo \""
						+this.getParametro(i).getTipo().getNombreTipo()+"\" y encontro un parametro de tipo \""+m.getParametro(i).getTipo().getNombreTipo()+"\"",m.getId().getLinea(),
						this.getId().getLexema());
		}
		
	}

}

package TablaDeSimbolos;

import Estructuras.Token;
import Excepciones.ExcepcionSemantico;

public class Variable {
    protected Token id;
    protected Tipo tipo;
    protected Clase clase;
    
    public Variable(Token id, Tipo tipo, Clase clase){
        this.id=id;
        this.tipo=tipo;
        this.clase=clase;
    }

    public Token getId() {
        return id;
    }
    public Tipo getTipo(){
        return tipo;
    }
    
    public String getNombre(){
        return id.getLexema();
    }
    
    public Clase getClase(){
        return clase;
    }
    public int getLinea(){
        return id.getLinea();
    }
    
    public int getColumna(){
        return id.getColumna();
    }
    
    public boolean esTipoValido() throws ExcepcionSemantico{
        if(!tipo.esTipoValido()){
            return false;
        }
        else
            return true;
    }
}

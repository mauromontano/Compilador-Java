package TablaDeSimbolos;

public class TipoNull extends TipoClase{

    
	public TipoNull() {
        super("null");
    }
    
    
    public boolean esCompatible(TipoMetodo tipoParam){
        if(tipoParam.esTipoClase())
            return true;
        else
            return false;
    }
    

   
    
}
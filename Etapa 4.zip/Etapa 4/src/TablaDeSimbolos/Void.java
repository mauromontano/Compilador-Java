package TablaDeSimbolos;

public class Void extends TipoMetodo{
	   
    public boolean esTipo(TipoMetodo tipo){
        return tipo instanceof Void;
    }
   
    
    
    public String getNombreTipo(){
        return "Void";
    }
    
    
    
    public boolean esTipoVoid(){

        return true;
    }
    
    public boolean esTipoValido() {
        return true;
    }
    
    public boolean esTipoClase(){
        return false;
    }
    
    public boolean esTipoBoolean(){
        return false;
    }
    
    
    public boolean esTipoInt() {
        return false;
    }

    
    public boolean esCompatible(TipoMetodo tipoParam) {
        return false;
    }

    
}

package TablaDeSimbolos;

import java.util.ArrayList;

import AST.Expresion;
import Estructuras.Token;
import Excepciones.ExcepcionSemantico;

public class Constructor extends Unidad{
    
    
	public Constructor(Token id) {
        super(id);
    }
    
    
    public String getNombreUnidad(){
        return "constructor";
    }
    
    
    public boolean esConstructor() {
        return true;
    }
    
    
    // Chequea si los par�metros actuales son compatibles con los par�metros formales
    
    public void parametrosCompatible(ArrayList<Expresion> parametrosActuales, int nroLinea, int nroColumna) throws ExcepcionSemantico{
        //Primero me fijo si la cantidad de par�metros es la misma
        if(parametrosActuales.size()!=nombresArgumentos.size())
            throw new ExcepcionSemantico("Se esta queriendo llamar al constructor "+id.getLexema()+" pero la cantidad de parametros actuales es "+parametrosActuales.size()+" y deberia ser "+nombresArgumentos.size(), nroLinea, id.getLexema());
        for(int i=0;i<parametrosActuales.size();i++){
            TipoMetodo tipoEvaluadoArgumento= parametrosActuales.get(i).chequear();
            if(tipoEvaluadoArgumento.esTipoVoid()){
                throw new ExcepcionSemantico("El parametro actual de la posicion "+(i+1)+" no debe ser void", nroLinea, id.getLexema());
            }
            if(!tipoEvaluadoArgumento.esCompatible(tiposOrdenados.get(i))){
                if(tiposOrdenados.get(i).esTipoClase()){
                    throw new ExcepcionSemantico("El tipo del parametro actual en la posicion "+(i+1)+" es "+tipoEvaluadoArgumento.getNombreTipo()+" pero deberia ser del tipo "+tiposOrdenados.get(i).getNombreTipo()+" o alguno de sus descendientes si es que los tuviese", nroLinea, id.getLexema());
                }else
                    throw new ExcepcionSemantico("El tipo del parametro actual en la posicion "+(i+1)+" es "+tipoEvaluadoArgumento.getNombreTipo()+" pero deberia ser del tipo "+tiposOrdenados.get(i).getNombreTipo(), nroLinea, id.getLexema());
            }
        }
    }

    
    public void chequear() throws ExcepcionSemantico {
        bloque.chequear();
    }
    

    
    
}

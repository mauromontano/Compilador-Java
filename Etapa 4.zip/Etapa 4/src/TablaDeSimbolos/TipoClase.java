package TablaDeSimbolos;

public class TipoClase extends Tipo{
    private String clase;

    public TipoClase(String clase) {
        this.clase = clase;
    }
    
    public boolean esTipoInt() {
        return false;
    }

    
    public boolean esTipo(TipoMetodo tipo){
        boolean toRet=false;
        if(tipo instanceof TipoClase){
            String nombreDelTipo= ((TipoClase)tipo).getNombreTipo();
            if(nombreDelTipo.equals(clase))
                toRet=true;
        }
        return toRet;

    }
    
    
    
    public boolean esTipoValido(){
    	if(Modulos.AnalizadorSintactico.tablaSimbolos.existeClase(clase))
    		return true;
        else
            return false;
    }
    
    
    public String getNombreTipo(){
        return clase;
    }
    
    public boolean esCompatible(TipoMetodo tipoParam) {
        boolean toRet=false;
        if(tipoParam.esTipoClase()){
            String nombreDelTipo= ((TipoClase)tipoParam).getNombreTipo();
            Clase miClase= Modulos.AnalizadorSintactico.tablaSimbolos.getClase(clase);
            toRet=miClase.esCompatible(nombreDelTipo);   
        }
        return toRet;
    }
    
    
    //No es un tipo primitivo ya que esto es el tipo clase
    
    public boolean esTipoPrimitivo() {
        return false;
    }
    
    public boolean esTipoClase(){
        return true;
    }
    
    public boolean esTipoBoolean() {
        return false;
    }



    
    
}
package TablaDeSimbolos;

public abstract class TipoPrimitivo extends Tipo{
	
    
    public boolean esTipoValido(){
        return true;
    }
    
    public boolean esTipoClase(){
        return false;
    }
    
    public boolean esCompatible(TipoMetodo tipoParam){
        return esTipo(tipoParam);
    }
    
    
    //Es un tipo primitivo ya que estamos en la clase de tipo primitivo
     
    public boolean esTipoPrimitivo(){
        return true;
    }

    
}

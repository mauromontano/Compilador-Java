package TablaDeSimbolos;

import Estructuras.Token;

public class Atributo extends Variable{
    
	private String visibilidad;
    
	public Atributo(Token id, Tipo tipo,String visibilidad, Clase clase) {
        super(id, tipo, clase);
        this.visibilidad=visibilidad;
    }
    
	public String getVisibilidad(){
        return visibilidad;
    }
	
}

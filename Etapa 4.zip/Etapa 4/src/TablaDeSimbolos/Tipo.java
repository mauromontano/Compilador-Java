package TablaDeSimbolos;

public abstract class Tipo extends TipoMetodo{
	
    public abstract boolean esTipoPrimitivo();
    
    
    public boolean esTipoVoid(){
        return false;
    }

    
}

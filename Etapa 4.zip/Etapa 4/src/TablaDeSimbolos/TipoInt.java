package TablaDeSimbolos;

public class TipoInt extends TipoPrimitivo{
    
    public boolean esTipo(TipoMetodo tipo){
        return tipo instanceof TipoInt;
    }
    
    
    public String getNombreTipo(){
        return "int";
    }


    public boolean esTipoBoolean() {
        return false;
    }
    
    
    public boolean esTipoInt() {
        return true;
    }


}
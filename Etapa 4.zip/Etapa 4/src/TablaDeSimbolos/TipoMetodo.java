package TablaDeSimbolos;

import Estructuras.Token;

public abstract class TipoMetodo {
	
    protected Token id;

    public abstract boolean esTipo(TipoMetodo tipo);
    public abstract boolean esTipoValido();
    public abstract String getNombreTipo();

    public abstract boolean esTipoVoid();
    public abstract boolean esTipoClase();
    public abstract boolean esTipoBoolean();
    public abstract boolean esTipoInt();
    public abstract boolean esCompatible(TipoMetodo tipoParam);

    
}